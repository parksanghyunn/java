package com.koreait.app.board.vo;

public class FilesVO {
	private String file_name;
	private int board_num;
	
	public FilesVO() {;}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public int getBoard_num() {
		return board_num;
	}

	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
}
